// import { useContext } from "react";
// import {CartContext} from "../context/CartContext";
// import '../css/cart.css';



// const Cart = () => {
//   const { cartItems, removeFromCart, increaseQuantity, decreaseQuantity } = useContext(CartContext);
 
//   const totalPrice = cartItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);
 
//   return (
//     <div>
//       <h2>Shopping Cart</h2>
//       {cartItems.length === 0 ? (
//         <p>Your cart is empty.</p>
//       ) : (
//         <div>
//           <ul>
//             {cartItems.map((item) => (
//               <li key={item.id}>
//                 {/* <img src={item.image} alt={item.title} width="50" /> */}
//                 <img src={item.thumbnail || item.image} alt={item.title} width="200" height='200' />

//                 <span>{item.title} - ${item.price} x {item.quantity}</span>
//                 <div>
//                   <button onClick={() => decreaseQuantity(item.id)}>-</button>
//                   <span>{item.quantity}</span>
//                   <button onClick={() => increaseQuantity(item.id)}>+</button>
//                 </div>
//                 <button onClick={() => removeFromCart(item.id)}>Remove</button>
//               </li>
//             ))}
//           </ul>
//           <h3>Total Price: ${totalPrice}</h3>
//         </div>
//       )}
//     </div>
//   );
// };
 
// export default Cart;


import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import '../css/cart.css';

const Cart = () => {
  const {
    cartItems,
    removeFromCart,
    increaseQuantity,
    decreaseQuantity,
    clearCart,
    getTotalPrice
  } = useContext(CartContext);

  const totalPrice = getTotalPrice().toFixed(2);

  return (
    <div>
      <h2>Shopping Cart</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          <ul>
            {cartItems.map((item) => (
              <li key={item.id}>
                <img src={item.thumbnail || item.image} alt={item.title} width="200" height="200" />
                <span>{item.title} - ${item.price} x {item.quantity}</span>
                <div>
                  <button onClick={() => decreaseQuantity(item.id)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => increaseQuantity(item.id)}>+</button>
                </div>
                <button onClick={() => removeFromCart(item.id)}>Remove</button>
              </li>
            ))}
          </ul>
          <h3>Total Price: ${totalPrice}</h3>
          <button onClick={clearCart}>Clear Cart</button>
        </div>
      )}
    </div>
  );
};

export default Cart;
